<!-- START FOOTER-ALT -->
<div class="footer-alt">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <p class="text-white-50 text-center mb-0">
                    Copyright<!--Copyright--> <?= date('Y', time()) ?> &copy; Company ABC. Developed by <a href="#" target="_blank">Team Fantastic</a>
                </p>
            </div><!--end col-->
        </div><!--end row-->
    </div><!--end container-->
</div>
<!-- END FOOTER-ALT-->