<footer class="container-fluid footer">
        Copyright<!--Copyright--> <?= date('Y', time()) ?> &copy; Company ABC. Developed by <a href="#" target="_blank">Team Fantastic</a>
        <a href="#" class="pull-right scrollToTop"><i class="fa fa-chevron-up"></i></a>
    </footer>
</section>
</body>
</html>